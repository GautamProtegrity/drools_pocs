package net.cloudburo.drools.model;

public class Person {
    private int clientId;
    private int age;
    private String status;

    public Person(int clientId, int age) {
        this.clientId = clientId;
        this.age = age;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}