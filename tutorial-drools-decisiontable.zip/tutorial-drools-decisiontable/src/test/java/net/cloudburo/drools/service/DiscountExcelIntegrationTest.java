package net.cloudburo.drools.service;

import static org.junit.Assert.assertEquals;

import net.cloudburo.drools.model.*;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.io.Resource;
import org.kie.api.runtime.ClassObjectFilter;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.internal.io.ResourceFactory;

import net.cloudburo.drools.config.DroolsBeanFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class DiscountExcelIntegrationTest {

    private KieSession kSession;

    @Before
    public void setup() {
//        Resource resource = ResourceFactory.newClassPathResource("net/cloudburo/drools/rules/NewRules.xls", getClass());
//        kSession = new DroolsBeanFactory().getKieSession(resource);
//        System.out.println(new DroolsBeanFactory().getDrlFromExcel("net/cloudburo/drools/rules/NewRules.xls"));
//          Resource resource = ResourceFactory.newClassPathResource("net/cloudburo/drools/rules/DroolsDiscount.xlsx");
//          kSession = new DroolsBeanFactory().getKieSession(resource);
//          System.out.println(new DroolsBeanFactory().getDrlFromExcel("net/cloudburo/drools/rules/DroolsDiscount.xlsx"));
        Resource resource = ResourceFactory.newClassPathResource("net/cloudburo/drools/rules/HealthMattersConfiguration-client.xls", getClass());
        kSession = new DroolsBeanFactory().getKieSession(resource);
        System.out.println(new DroolsBeanFactory().getDrlFromExcel("net/cloudburo/drools/rules/HealthMattersConfiguration-client.xls"));
    }

    @Test
    public void giveIndvidualLongStanding_whenFireRule_thenCorrectDiscount() throws Exception {
        // Add a Customer with its personal data and needs, used for the LHS Decision
        Customer customer = new Customer();
        customer.setLifestage(Customer.CustomerLifeStage.GETTINGSTARTED);
        customer.setAssets(Customer.CustomerAssets.FROM150KTO300K);
        customer.addNeed(Customer.CustomerNeed.LIFEINSURANCE);
        customer.addNeed(Customer.CustomerNeed.SAVINGACCOUNT);
        customer.addNeed(Customer.CustomerNeed.MORTAGE);
        kSession.insert(customer);
        // Now we add the global variable which we use to communicate back our
        Offer offer = new Offer();
        kSession.setGlobal("offer", offer);
        kSession.fireAllRules();
        assertEquals(offer.getDiscount(), 10);
        assertEquals(offer.getFinancialPackage(), Offer.ProductPackage.CAREERFOCUSED_PACKAGE);
        assertEquals(offer.getProducts().size(),2);
    }

    @Test
    public void testHMCClient(){
        ClientRelationship cr1 = new ClientRelationship();
        cr1.setAccountNum("ACCNO1");
        cr1.setClientId("0012556");
        ClientRelationship cr2 = new ClientRelationship();
        cr2.setClientId("0012557");
        cr2.setAccountNum("ACCNO2");
        kSession.insert(cr1);
        kSession.insert(cr2);
        kSession.fireAllRules();
        System.out.println(cr1.toString());
        System.out.println(cr2.toString());
    }

    @Test
    public void testPerson(){
        // Create and insert test data
        Person person1 = new Person(1003, 66);
        Person person2 = new Person(1006, 70);
        Person person3 = new Person(1002, 66);
        Person person4 = new Person(1003, 64);

        kSession.insert(person1);
        kSession.insert(person2);
        kSession.insert(person3);
        kSession.insert(person4);

        // Fire all rules
        kSession.fireAllRules();

        // Print results
        printPersonStatus("Person 1", person1);
        printPersonStatus("Person 2", person2);
        printPersonStatus("Person 3", person3);
        printPersonStatus("Person 4", person4);
    }

    private static void printPersonStatus(String label, Person person) {
        System.out.println(label + " - Client ID: " + person.getClientId() +
                ", Age: " + person.getAge() + ", Status: " + person.getStatus());
    }
}
