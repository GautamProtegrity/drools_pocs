package net.cloudburo.drools.model;


import org.drools.core.io.impl.ClassPathResource;
import org.kie.api.KieServices;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieModule;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

public class DroolsTest {

    public static void main(String[] args) {
        try {
            // Initialize Drools services
            KieServices kieServices = KieServices.get();
            KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
//            kieFileSystem.write(new ClassPathResource("rules.drl")); // Load the rule file
            kieFileSystem.write(new ClassPathResource("rules.xls"));

            // Build the KieContainer
            KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem).buildAll();
            KieModule kieModule = kieBuilder.getKieModule();
            KieContainer kieContainer = kieServices.newKieContainer(kieModule.getReleaseId());

            // Create a new KieSession
            KieSession kieSession = kieContainer.newKieSession();

            // Create and insert test data
            Person person1 = new Person(1003, 66);
            Person person2 = new Person(1006, 70);
            Person person3 = new Person(1002, 66);
            Person person4 = new Person(1003, 64);

            kieSession.insert(person1);
            kieSession.insert(person2);
            kieSession.insert(person3);
            kieSession.insert(person4);

            // Fire all rules
            kieSession.fireAllRules();

            // Print results
            printPersonStatus("Person 1", person1);
            printPersonStatus("Person 2", person2);
            printPersonStatus("Person 3", person3);
            printPersonStatus("Person 4", person4);

            // Dispose the session
            kieSession.dispose();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void printPersonStatus(String label, Person person) {
        System.out.println(label + " - Client ID: " + person.getClientId() +
                ", Age: " + person.getAge() + ", Status: " + person.getStatus());
    }
}