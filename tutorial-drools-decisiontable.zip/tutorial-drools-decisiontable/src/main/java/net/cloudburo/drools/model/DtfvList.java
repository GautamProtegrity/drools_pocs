package net.cloudburo.drools.model;

import java.util.ArrayList;
import java.util.List;

public class DtfvList {

    private String factval;

    public String getFactval() {
        return factval;
    }

    public void setFactval(String factval) {
        this.factval = this.factval.concat(","+factval);
    }
}
