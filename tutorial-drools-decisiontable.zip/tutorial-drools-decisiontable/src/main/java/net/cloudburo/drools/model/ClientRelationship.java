package net.cloudburo.drools.model;

import java.util.ArrayList;
import java.util.List;

public class ClientRelationship {

    private String clientId;
    private String accountNum;
    private String factId;
    private String value;
    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getFactId() {
        return factId;
    }

    public void setFactId(String factId) {
        this.factId = factId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "ClientRelationship{" +
                "accountNum='" + accountNum + '\'' +
                ", clientId='" + clientId + '\'' +
                ", factId='" + factId + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
