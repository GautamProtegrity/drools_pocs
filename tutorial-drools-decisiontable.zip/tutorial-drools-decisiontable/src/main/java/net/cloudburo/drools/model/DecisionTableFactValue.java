package net.cloudburo.drools.model;

public class DecisionTableFactValue {

    private String factId;
    private String value;

    public String getFactId() {
        return factId;
    }

    public void setFactId(String factId) {
        this.factId = factId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "DecisionTableFactValue{" +
                "factId='" + factId + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
